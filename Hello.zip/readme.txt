$$\   $$\           $$\ $$\           
$$ |  $$ |          $$ |$$ |          
$$ |  $$ | $$$$$$\  $$ |$$ | $$$$$$\  
$$$$$$$$ |$$  __$$\ $$ |$$ |$$  __$$\ 
$$  __$$ |$$$$$$$$ |$$ |$$ |$$ /  $$ |
$$ |  $$ |$$   ____|$$ |$$ |$$ |  $$ |
$$ |  $$ |\$$$$$$$\ $$ |$$ |\$$$$$$  |
\__|  \__| \_______|\__|\__| \______/

By N17Pro3874 And MAR324Imposter (ft. N17Pro3426)

harmless version is wont hurt your pc.
harmful version i will kill your pc.

Works best in: Windows XP
Made in: C++
Malware type: Trojan
Damage rate: Destructive

run it on wm Like (VirtualBox or VMWare)
Credits to GetMBR for Hue function